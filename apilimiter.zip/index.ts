import { ApiLimiter } from "./src/ApiLimiter";

const api = ApiLimiter.getInstance();

(async () => {
  let res;
  const data = { msg: "Hello World!"}

  res = await api.makeRequest("https://reqbin.com/sample/post/json", "POST", data);
  console.log(res);
  res = await api.makeRequest("https://www.reddit.com/r/popular.json", "POST", data);
  console.log(res);
  res = await api.makeRequest("https://www.reddit.com/r/popular.json", "POST", data);
  console.log(res);
  res = await api.makeRequest("https://www.reddit.com/r/popular.json", "POST", data);
  console.log(res);
  res = await api.makeRequest("https://www.reddit.com/r/popular.json", "POST", data);
  console.log(res);
  res = await api.makeRequest("https://www.reddit.com/r/popular.json", "POST", data);
  console.log(res);

})();
