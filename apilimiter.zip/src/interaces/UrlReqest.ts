export interface UrlRequest {
  actualCall: number;
  urlCall: string;
  dateCall: Date;
  rateLimitForUrl: number;
}

export interface ApiResponse {
  data: any;
  status: number;
  error: string;
}


export interface OptionsRequest {
  method: string;
  headers?: Record<string, string>;
}

export type MethodRequest = "GET" | "POST" | "PATCH" | "DELETE";
