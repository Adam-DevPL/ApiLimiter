import { request } from "./httpsMethods";
import {
  ApiResponse,
  MethodRequest,
  UrlRequest,
} from "./interaces/UrlReqest";
import { findOrCreateUrl, updateUrlsArray } from "./utils";

export class ApiLimiter {
  private static instance: ApiLimiter;
  private rateLimitPerMinute: number = 5;
  private urlsArray: UrlRequest[] = [];

  private constructor() {}

  public static getInstance(): ApiLimiter {
    if (!ApiLimiter.instance) {
      ApiLimiter.instance = new ApiLimiter();
    }
    return ApiLimiter.instance;
  }

  async makeRequest(
    url: string,
    method: MethodRequest = "GET",
    data: any = null
  ): Promise<ApiResponse> {
    const foundUrl = findOrCreateUrl(
      this.urlsArray,
      url,
      this.rateLimitPerMinute
    );
    const nowDate = new Date();

    const elapsedTimeInMinutes =
      nowDate.getTime() - foundUrl.dateCall.getTime();

    if (elapsedTimeInMinutes > 1000 * 60) {
      foundUrl.dateCall = nowDate;
      foundUrl.actualCall = 0;
    } else {
      foundUrl.actualCall += 1;
    }

    updateUrlsArray(this.urlsArray, foundUrl);

    if (foundUrl.actualCall <= foundUrl.rateLimitForUrl) {
      try {
        return Promise.resolve(await request(foundUrl.urlCall, method, data));
      } catch (error) {
        return Promise.resolve({
          data: null,
          status: 404,
          error: error,
        });
      }
    } else {
      return Promise.resolve({
        data: null,
        status: 404,
        error: "Limit of enters exceeded",
      });
    }
  }

  setRateLimit(limit: number) {
    this.rateLimitPerMinute = limit;
  }
}
