import { UrlRequest } from "./interaces/UrlReqest";

export const findOrCreateUrl = (
  urlsArray: UrlRequest[],
  url: string,
  rateLimitPerMinute: number
): UrlRequest => {
  let foundUrl = urlsArray.find((urlFromList) => urlFromList.urlCall === url);
  if (!foundUrl) {
    foundUrl = {
      actualCall: 0,
      urlCall: url,
      dateCall: new Date(),
      rateLimitForUrl: rateLimitPerMinute,
    };
    urlsArray.push(foundUrl);
  }

  return foundUrl;
};

export const updateUrlsArray = (
  urlsArray: UrlRequest[],
  urlRequest: UrlRequest
): void => {
  urlsArray.forEach((urlFromList) => {
    if (urlFromList.urlCall === urlRequest.urlCall) {
      urlFromList.dateCall = urlRequest.dateCall;
      urlFromList.actualCall = urlRequest.actualCall;
    }
  });
};
